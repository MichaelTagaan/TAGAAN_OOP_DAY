package TagaanRPG;

public class Swordsman extends Character {
    
    public Swordsman() {
        super(100, 10, 10);
    }
      
}
